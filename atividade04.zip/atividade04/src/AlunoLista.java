public class AlunoLista {

    private String nome;

    private int idade;

    private AlunoLista proximo;
}
